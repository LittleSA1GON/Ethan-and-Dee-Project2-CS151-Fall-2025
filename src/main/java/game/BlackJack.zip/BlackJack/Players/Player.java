package game.BlackJack.Players;

import java.util.List;
import game.BlackJack.SupportingFiles.Card;

public abstract class Player {
    public String username;
    protected List<Card> hand;
    protected int currScore;
    protected int money;

    abstract void hit();

    abstract void stand();

}
